#!/system/bin/sh
# ram-perf-tuning: transparent, auditable runtime tuning, informed by
# reviewing (not blindly flashing) "Yet Another RAM Module" and "Yet Another
# Performance Module" - both are compiled binaries built/labelled for much
# newer Android (one explicitly for Android 16 QPR2); this device runs
# Android 11 on a Linux 4.14 MTK kernel with no PSI/memcg (see project docs).
#
# Every single write below is guarded by "does this path even exist on this
# kernel" first - anything not applicable to this device/kernel just safely
# no-ops instead of guessing or trusting an opaque binary calibrated for a
# different OS generation. Values are chosen for THIS device's ~3-4GB RAM,
# not copied from the source modules (which target 8GB+ phones).
#
# Deliberately NOT included: GPU boost / CPU scheduler cgroup tuning
# (cpuctl uclamp, schedtune boost/prefer_idle) from the performance module -
# those actively override Android's own EAS scheduler decisions, which is a
# meaningfully higher-risk category (can fight the OS instead of helping it)
# than the tunables below. Flag if you want that layer added separately.

MODDIR=${0%/*}

wait_until_boot_complete() {
  while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 5
  done
}
wait_until_boot_complete
sleep 5

set_if_exists() {
  # $1 = path, $2 = value
  [ -w "$1" ] && echo "$2" > "$1" 2>/dev/null
}

log() { echo "[ram-perf-tuning] $1" >> /data/local/tmp/ram-perf-tuning.log 2>/dev/null; }

log "applying at $(date)"

# =========================================================
# VM / memory management (from reviewing YARM's tunable set -
# these are universal Linux mm sysctls, nothing Android-16-specific
# about the mechanism itself, just the specific values chosen)
# =========================================================

# Favor zram (fast, compressed RAM) over dropping caches outright - safe
# and standard since zram exists on this device (CONFIG_ZRAM=y).
set_if_exists /proc/sys/vm/swappiness 100

# Reduce large write-back bursts on flash storage (phones benefit from
# smaller, more frequent flushes vs desktop-oriented defaults of 10/20).
set_if_exists /proc/sys/vm/dirty_background_ratio 5
set_if_exists /proc/sys/vm/dirty_ratio 10
set_if_exists /proc/sys/vm/dirty_expire_centisecs 200
set_if_exists /proc/sys/vm/dirty_writeback_centisecs 200

# Keep the OOM killer from panicking the whole system; kill the actual
# offending allocation instead - safety-oriented, not a speed tweak.
set_if_exists /proc/sys/vm/oom_kill_allocating_task 0
set_if_exists /proc/sys/vm/panic_on_oom 0

# Standard, conservative - avoid touching min_free_kbytes/extra_free_kbytes:
# those interact directly with lmkd's minfree thresholds, and getting the
# relationship wrong can make memory pressure WORSE, not better, especially
# without PSI/memcg to smooth things out. Left at kernel/ROM default.

set_if_exists /proc/sys/vm/vfs_cache_pressure 100
set_if_exists /proc/sys/vm/page-cluster 0

# =========================================================
# I/O tuning (generic, existence-checked - this kernel defaults to the
# "deadline" scheduler, not CFQ/BFQ, so some paths below intentionally
# won't exist here and will just no-op)
# =========================================================

set_if_exists /sys/block/mmcblk0/queue/read_ahead_kb 128
set_if_exists /sys/block/mmcblk0/queue/nomerges 0
set_if_exists /sys/block/mmcblk0/queue/rotational 0
set_if_exists /sys/block/mmcblk0/iosched/fifo_batch 4

for z in /sys/block/zram0; do
  set_if_exists "$z/queue/read_ahead_kb" 128
done

# =========================================================
# Network (generic Linux/Android tunables, existence-checked)
# =========================================================

set_if_exists /proc/sys/net/ipv4/tcp_fastopen 3
set_if_exists /proc/sys/net/ipv4/tcp_slow_start_after_idle 0
set_if_exists /proc/sys/net/core/somaxconn 256

# =========================================================
# MediaTek PPM (Power Performance Manager) - driver confirmed present
# in this kernel's source (drivers/misc/mediatek/base/power/ppm_v3),
# so this path is plausible, though not live-verified on this exact
# device yet. Only enabling it, no aggressive override values.
# =========================================================

set_if_exists /proc/ppm/enabled 1

log "done"
exit 0
