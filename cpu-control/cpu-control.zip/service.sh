#!/system/bin/sh
# cpu-control v2: charging-aware CPU throttling
#
# Goal: while the phone is charging, cap CPU below stock so background
# tasks slow down and device heat stays near the 40C target. When battery
# temp exceeds HOT_TEMP, caps harden further. Below COOL_TEMP they relax
# (hysteresis, prevents oscillation). Unplugged = stock frequencies, no
# interference at all.
#
# Why this exists: the kernel's own charger thermal tables (mtk_charger.c
# thermal_mitigation_* + smb1351 qcom,thermal-mitigation-*) only cut
# CHARGING CURRENT, which limits heat from the charger IC but does nothing
# about heat from sustained CPU load while charging. This module covers the
# load side.
#
# Tuning (all units: kHz for frequencies, 0.1C for temps):
#   CHARGE_MAX_BIG/LITTLE - cap while charging, normal temp
#   HOT_MAX_BIG/LITTLE    - cap while charging, above HOT_TEMP
#   HOT_TEMP/COOL_TEMP    - 400 = 40.0C (battery temp is 0.1C units on MTK)
#   CHECK_INTERVAL        - seconds between checks
#
# Stock ceilings on this SoC (verified, not assumed): 2000000 kHz big,
# 1700000 kHz little. Values below are the charge-time caps.

CHARGE_MAX_BIG=1600000
CHARGE_MAX_LITTLE=1300000
HOT_MAX_BIG=1400000
HOT_MAX_LITTLE=1100000
HOT_TEMP=400
COOL_TEMP=380
CHECK_INTERVAL=5

BATT_TEMP=/sys/class/power_supply/battery/temp
BATT_STATUS=/sys/class/power_supply/battery/status

current_cap=          # "" = stock (unplugged), "cool" = charge cap, "hot" = hard cap
stored=""

cap_all() {
  for policy in /sys/devices/system/cpu/cpufreq/policy*; do
    [ -d "$policy" ] || continue
    max_avail=$(cat "$policy/cpuinfo_max_freq" 2>/dev/null)
    [ -z "$max_avail" ] && continue
    if [ "$max_avail" -gt 1800000 ]; then
      echo "$1" > "$policy/scaling_max_freq" 2>/dev/null
    else
      echo "$2" > "$policy/scaling_max_freq" 2>/dev/null
    fi
  done
}

restore_stock() {
  for policy in /sys/devices/system/cpu/cpufreq/policy*; do
    [ -d "$policy" ] || continue
    max_avail=$(cat "$policy/cpuinfo_max_freq" 2>/dev/null)
    [ -z "$max_avail" ] && continue
    echo "$max_avail" > "$policy/scaling_max_freq" 2>/dev/null
  done
}

apply() {
  if [ "$1" = "cool" ]; then
    cap_all "$CHARGE_MAX_BIG" "$CHARGE_MAX_LITTLE"
  elif [ "$1" = "hot" ]; then
    cap_all "$HOT_MAX_BIG" "$HOT_MAX_LITTLE"
  fi
}

is_charging() {
  st=$(cat "$BATT_STATUS" 2>/dev/null)
  [ "$st" = "Charging" ] || [ "$st" = "Full" ]
}

loop() {
  while :; do
    if is_charging; then
      temp=$(cat "$BATT_TEMP" 2>/dev/null)
      [ -z "$temp" ] && temp=0
      if [ "$temp" -ge "$HOT_TEMP" ]; then
        [ "$current_cap" = "hot" ] || { apply hot; current_cap=hot; }
      elif [ "$temp" -le "$COOL_TEMP" ]; then
        [ "$current_cap" = "cool" ] || { apply cool; current_cap=cool; }
      fi
    else
      [ -z "$current_cap" ] || { restore_stock; current_cap=""; }
    fi
    sleep "$CHECK_INTERVAL"
  done
}

loop &
